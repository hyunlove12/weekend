from mnist_test.number_checker import NumberChecker
from mnist_test.fashion_checker import FashionChecker
if __name__ == '__main__':
    #t = NumberChecker()
    #t.execute()
    f = FashionChecker()
    f.create_model()