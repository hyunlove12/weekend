import mglearn
import matplotlib.pyplot as plt
mglearn.plots.plot_knn_regression(n_neighbors=3) #n_neighbors -> 가장 가까운 것들의 개수(3개를 찾는다) //regression -> 거리가 가까운 데이터끼리 묶는 것 // classification -> 군집화
# 이웃한 값 1일 때 알고리즘
plt.show()
