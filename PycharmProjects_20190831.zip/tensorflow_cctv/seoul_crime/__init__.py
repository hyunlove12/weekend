from seoul_crime.controller import Controller

if __name__ == "__main__":
    ctrl = Controller()
    ctrl.execute()
