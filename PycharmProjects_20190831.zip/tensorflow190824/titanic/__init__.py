from titanic.controller import TitanicController
if __name__ == "__main__":
    ctrl = TitanicController()
    t = ctrl.create_train()