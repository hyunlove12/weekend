class Contact:
    def __init__(self, name, phone, email, addr):
        self.name = name
        self.phone = phone
        self.email = email
        self.addr = addr

    def to_string(self):
        t = '이름 : {} \n 이름 : {} \n 이름 : {} \n 이름 : {} \n'\
                .format(self.name, self.phone, self.email, self.addr)

        return t