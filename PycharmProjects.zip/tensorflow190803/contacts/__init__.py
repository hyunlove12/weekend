from contacts.controller import ContactsController
from contacts.model import ContactsModel
if __name__ == '__main__':
    ctrl = ContactsController()
    ctrl.run()
    #model = ContactsModel()
    #model.set_contact()
    #model.get_contacts()
    #print(model.print_info())
